<div class="adv-wrapper">
	<?php echo houzez_option('adsense_space_2');?>
</div>