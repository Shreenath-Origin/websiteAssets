<div class="back-to-top-wrap">
	<a href="#top" id="scroll-top" class="btn btn-primary btn-back-to-top">
		<i class="houzez-icon icon-arrow-up-1"></i>
	</a>
</div>