<div class="listing-switch-view">
	<ul class="list-inline">
		<li class="list-inline-item">
			<a class="switch-btn btn-list">
				<i class="houzez-icon icon-layout-bullets"></i>
			</a>
		</li>
		<li class="list-inline-item">
			<a class="switch-btn btn-grid">
				<i class="houzez-icon icon-layout-module-1"></i>
			</a>
		</li>
	</ul>
</div><!-- listing-switch-view -->