 <?php if( houzez_option('copy_rights') != '' ) { ?>
<div class="footer-copyright">
	&copy; <?php echo houzez_option('copy_rights'); ?>
</div><!-- footer-copyright -->
<?php } ?>